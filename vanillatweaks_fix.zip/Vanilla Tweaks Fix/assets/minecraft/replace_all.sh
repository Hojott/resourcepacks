#!/bin/sh

find ./lang/* |\
while read filename
do
     cp ./en_us.json $filename
done

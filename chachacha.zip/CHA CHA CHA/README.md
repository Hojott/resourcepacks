# CHA CHA CHA

Changes Cat music disk to Cha Cha Cha by Käärijä

Music downloaded from Youtube https://youtu.be/TVlyw6T4bcE
Image by Yuk Weeden (Public Domain)

(also adds Cha Cha Cha to Seek goat horn, that can be enabled by renaming the ogg file in assets/minecraft/sounds/goat_horn to call2.ogg)
